#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>


#define error_message(FMT, ...) printf(FMT, __VA_ARGS__)
 


long getFileSize(const char *fileName)
{
    if(fileName == NULL)
        return -1;
    FILE *f = fopen(fileName, "rb");
    if (!f)
        return -1;
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fclose(f);
    return fsize; 
}

int readFileToBuffer(const char *fileName, char *buffer, int bufferLength)
{
    FILE *f = fopen(fileName, "rb");
    if (!f)
        return 0;
    long readBytes = fread(buffer, 1, bufferLength, f);
    fclose(f);
    return readBytes;
}
bool fileExists(const char *fileName)
{
    FILE *f = fopen(fileName, "rb");
    if (!f)
        return false; // false: not exists
    fclose(f);
    return true; // true: exists
}


int set_interface_attribs (int fd, int speed, int parity);
void set_blocking (int fd, int should_block);
#define __USE_XOPEN_EXTENDED
int main(int argc, char ** argv) {
    const char * portname = "/dev/ttyACM1";
    int fd = open (portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0)
    {
        error_message ("error %d opening %s: %s", errno, portname, strerror (errno));
        return 1;
    }
 
    set_interface_attribs (fd, B115200, 0);  // set speed to 115,200 bps, 8n1 (no parity)
    set_blocking (fd, 1);                    // set blocking
    // //
    // // while (1) {
    //    printf("Print to say: ");
    //     char input[100];
    //     strcpy(input, argv[1]);
    // //    fgets(input, 100, stdin);
    // //    input[strlen(input) - 1] = '\0';
    //     write(fd, &input, strlen(input));
    //     // write(fd, &argv[1], strlen(argv[1]));
    // // puts(argv[1]);
    // //write(fd, &argv[1], strlen(argv[1]));
    //     usleep ((2 + 25) * 100);
    // // }

    if(!fileExists(argv[1])){
         error_message ("No such file: %s", argv[1]);
        return 1;
    }
    long bites = getFileSize(argv[1]);
    char *buffer = malloc( (bites + 1) * sizeof(char));
    bites = readFileToBuffer(argv[1], buffer, bites) / sizeof(char);
    printf("Size is %li", bites);
    buffer[bites] = '\0';
    char res[100];
    strcpy(res, buffer);
    free(buffer);
    puts(res);
    // while(1){
        write(fd, &res, strlen(res));
        usleep ((2 + 25) * 100);
    // }
    return 0;
}
int set_interface_attribs (int fd, int speed, int parity)
{
   struct termios tty;
   memset (&tty, 0, sizeof tty);
   if (tcgetattr (fd, &tty) != 0)
   {
       error_message ("error %d from tcgetattr", errno);
       return -1;
   }
 
   cfsetospeed (&tty, speed);
   cfsetispeed (&tty, speed);
 
   tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
   // disable IGNBRK for mismatched speed tests; otherwise receive break
   // as \000 chars
   tty.c_iflag &= ~IGNBRK;         // disable break processing
   tty.c_lflag = 0;                // no signaling chars, no echo,
                                   // no canonical processing
   tty.c_oflag = 0;                // no remapping, no delays
   tty.c_cc[VMIN]  = 0;            // read doesn't block
   tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout
 
   tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl
 
   tty.c_cflag |= (CLOCAL | CREAD);// ignore modem controls,
                                   // enable reading
   tty.c_cflag &= ~(PARENB | PARODD);      // shut off parity
   tty.c_cflag |= parity;
   tty.c_cflag &= ~CSTOPB;
   tty.c_cflag &= ~CRTSCTS;
 
   if (tcsetattr (fd, TCSANOW, &tty) != 0)
   {
       error_message ("error %d from tcsetattr", errno);
       return -1;
   }
   return 0;
}
 
void set_blocking (int fd, int should_block)
{
   struct termios tty;
   memset (&tty, 0, sizeof tty);
   if (tcgetattr (fd, &tty) != 0)
   {
       error_message ("error %d from tggetattr", errno);
       return;
   }
 
   tty.c_cc[VMIN]  = should_block ? 1 : 0;
   tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout
 
   if (tcsetattr (fd, TCSANOW, &tty) != 0)
       error_message ("error %d setting term attributes", errno);
}