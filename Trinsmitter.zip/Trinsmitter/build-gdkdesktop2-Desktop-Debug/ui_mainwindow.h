/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_2;
    QFormLayout *formLayout;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *optionsButton;
    QLineEdit *sayEdit;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *sayButton;
    QLabel *portLabel;
    QLabel *addresLabel;
    QMenuBar *menuBar;
    QMenu *menuSimba_Inc_Transmitter_manipulator_release_ver_1_0;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(419, 202);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout_2 = new QGridLayout(centralWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        optionsButton = new QPushButton(centralWidget);
        optionsButton->setObjectName(QStringLiteral("optionsButton"));

        horizontalLayout->addWidget(optionsButton);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout);

        sayEdit = new QLineEdit(centralWidget);
        sayEdit->setObjectName(QStringLiteral("sayEdit"));
        sayEdit->setMaxLength(100);

        formLayout->setWidget(2, QFormLayout::FieldRole, sayEdit);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        sayButton = new QPushButton(centralWidget);
        sayButton->setObjectName(QStringLiteral("sayButton"));
        sayButton->setEnabled(false);

        horizontalLayout_2->addWidget(sayButton);


        formLayout->setLayout(3, QFormLayout::FieldRole, horizontalLayout_2);


        gridLayout_2->addLayout(formLayout, 0, 0, 1, 1);

        portLabel = new QLabel(centralWidget);
        portLabel->setObjectName(QStringLiteral("portLabel"));

        gridLayout_2->addWidget(portLabel, 1, 0, 1, 1);

        addresLabel = new QLabel(centralWidget);
        addresLabel->setObjectName(QStringLiteral("addresLabel"));

        gridLayout_2->addWidget(addresLabel, 3, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 419, 25));
        menuSimba_Inc_Transmitter_manipulator_release_ver_1_0 = new QMenu(menuBar);
        menuSimba_Inc_Transmitter_manipulator_release_ver_1_0->setObjectName(QStringLiteral("menuSimba_Inc_Transmitter_manipulator_release_ver_1_0"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuSimba_Inc_Transmitter_manipulator_release_ver_1_0->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Simba Inc Transmitter manipulator realese ver. 1.0", 0));
        label_2->setText(QApplication::translate("MainWindow", "Text to say", 0));
        optionsButton->setText(QApplication::translate("MainWindow", "Options", 0));
        sayButton->setText(QApplication::translate("MainWindow", "Say", 0));
        portLabel->setText(QApplication::translate("MainWindow", "/dev/ttyACM1", 0));
        addresLabel->setText(QApplication::translate("MainWindow", "115200", 0));
        menuSimba_Inc_Transmitter_manipulator_release_ver_1_0->setTitle(QApplication::translate("MainWindow", "Simba Inc. Transmitter manipulator release ver. 1.0", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
