/********************************************************************************
** Form generated from reading UI file 'optiondialog.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPTIONDIALOG_H
#define UI_OPTIONDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_OptionDialog
{
public:
    QGridLayout *gridLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *devName;
    QDialogButtonBox *OkButton;
    QSpinBox *addressBox;

    void setupUi(QDialog *OptionDialog)
    {
        if (OptionDialog->objectName().isEmpty())
            OptionDialog->setObjectName(QStringLiteral("OptionDialog"));
        OptionDialog->resize(269, 136);
        gridLayout = new QGridLayout(OptionDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(OptionDialog);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        label_2 = new QLabel(OptionDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        devName = new QLineEdit(OptionDialog);
        devName->setObjectName(QStringLiteral("devName"));

        formLayout->setWidget(0, QFormLayout::FieldRole, devName);

        OkButton = new QDialogButtonBox(OptionDialog);
        OkButton->setObjectName(QStringLiteral("OkButton"));
        OkButton->setOrientation(Qt::Vertical);
        OkButton->setStandardButtons(QDialogButtonBox::Ok);

        formLayout->setWidget(2, QFormLayout::FieldRole, OkButton);

        addressBox = new QSpinBox(OptionDialog);
        addressBox->setObjectName(QStringLiteral("addressBox"));
        addressBox->setMaximum(1000000000);
        addressBox->setValue(115200);

        formLayout->setWidget(1, QFormLayout::FieldRole, addressBox);


        gridLayout->addLayout(formLayout, 0, 0, 1, 1);


        retranslateUi(OptionDialog);
        QObject::connect(OkButton, SIGNAL(accepted()), OptionDialog, SLOT(accept()));
        QObject::connect(OkButton, SIGNAL(rejected()), OptionDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(OptionDialog);
    } // setupUi

    void retranslateUi(QDialog *OptionDialog)
    {
        OptionDialog->setWindowTitle(QApplication::translate("OptionDialog", "Dialog", 0));
        label->setText(QApplication::translate("OptionDialog", "Device name", 0));
        label_2->setText(QApplication::translate("OptionDialog", "Port adress", 0));
        devName->setText(QApplication::translate("OptionDialog", "/dev/ttyACM1", 0));
    } // retranslateUi

};

namespace Ui {
    class OptionDialog: public Ui_OptionDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPTIONDIALOG_H
