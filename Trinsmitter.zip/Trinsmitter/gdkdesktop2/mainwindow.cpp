#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "optiondialog.h"
#include <iostream>
#include <QFile>
#include <QTextStream>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_sayEdit_textChanged(const QString &arg1)
{
    bool validate = ui->sayEdit->text().isEmpty();
    ui->sayButton->setEnabled(!validate);
}

void MainWindow::on_sayButton_clicked()
{
    std::string toSay = ui->sayEdit->text().toStdString();
    //std::cout << toSay << std::endl;
    //@todo

    QString filename = "SAY.txt";

    QFile loadFile(filename);
    if(loadFile.open(QIODevice::WriteOnly | QIODevice::Text)){
        QTextStream writeStream(&loadFile);
        writeStream << QString::fromStdString(toSay);
        loadFile.close();
    }
    std::string command = "./a.out " + filename.toStdString();
    system(command.c_str());
}

void MainWindow::on_optionsButton_clicked()
{
    OptionDialog dialog(this, ui->portLabel->text(), ui->addresLabel->text());
    dialog.exec();
    ui->addresLabel->setText(dialog.getAdress());
    ui->portLabel->setText(dialog.getName());
}
