#include "optiondialog.h"
#include "ui_optiondialog.h"

OptionDialog::OptionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OptionDialog)
{
    ui->setupUi(this);
}



OptionDialog::OptionDialog(QWidget *parent, QString name, QString adress) :
    QDialog(parent),
    ui(new Ui::OptionDialog)
{
    ui->setupUi(this);
    ui->addressBox->setValue(adress.toInt());
    ui->devName->setText(name);
}

QString OptionDialog::getAdress(){
    return ui->addressBox->text();
}
QString OptionDialog::getName(){
    return ui->devName->text();
}
