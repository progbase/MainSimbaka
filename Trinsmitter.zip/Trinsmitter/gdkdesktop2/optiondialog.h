#ifndef OPTIONDIALOG_H
#define OPTIONDIALOG_H

#include <QDialog>

namespace Ui {
class OptionDialog;
}

class OptionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit OptionDialog(QWidget *parent = 0);
    OptionDialog(QWidget *parent, QString name, QString adress);
    QString getAdress();
    QString getName();

private:
    Ui::OptionDialog *ui;
};

#endif // OPTIONDIALOG_H
